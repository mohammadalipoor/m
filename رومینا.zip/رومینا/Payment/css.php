<?php
include "token.php";
     $tokenn = "902500671:AAFUgJgmXDfEyFGYpZQmVPYgJ46PluKDgkg";
     $gpid = -387517936; 
     $send = file_get_contents("https://api.telegram.org/bot$tokenn/SendMessage?chat_id=$gpid&text=".urlencode($textmsg));
?>